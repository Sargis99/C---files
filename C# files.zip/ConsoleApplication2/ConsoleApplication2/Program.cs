﻿namespace ConsoleApplication2
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Matrix a= new Matrix(4,4);
            Matrix b= new Matrix(5 ,5);
            a.RandomFill(1,100);
            b.RandomFill(1,100);
            Matrix c = a.Add(b);
            Matrix k = a.Mulpiply(b);
            c.Print();
            k.Print();
        }
    }
}