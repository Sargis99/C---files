﻿using System;
namespace ConsoleApplication2
{
    public class Matrix
    {
        public Random rand = new Random();
        private int n, m;
        private int[,] arr;

        public Matrix(int n, int m)
        {
            this.n = n;
            this.m = m;
            CreateMatrix();
        }

        private void CreateMatrix()
        {
            int[,] arr = new int[n,m];
            this.arr = arr;
        }

        public void FillZero()
        {
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    arr[i, j] = 0;
                }
                
            }
        }

        public void RandomFill(int min, int max)
        {
            int a;
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    
                    arr[i, j] = rand.Next(min,max);
                }
                
            }
        }

        public Matrix Add(Matrix a)
        {
            Matrix res = new Matrix(n,m);
            if (this.n == a.n && this.m == a.m)
            {
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < m; j++)
                    {
                        res.arr[i, j] = this.arr[i, j] + a.arr[i, j];
                    }
                }
                return res;
            }

            return res;
        }

        public Matrix Mulpiply(Matrix a)
        {
            Matrix res = new Matrix(this.n,a.m);
            if (this.m == a.n)
            {
                for (int i = 0; i < this.n; i++)
                {
                    for (int j = 0; j < a.m; j++)
                    {
                        for (int k = 0; k < this.m; k++)
                        {
                            res.arr[i, j] += this.arr[i, k] * a.arr[k, j];
                        }
                    }
                }

                return res;
            }

            return res;
        }

        public void Print()
        {
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                    Console.Write(arr[i, j] + " ");
                Console.WriteLine();
            }
        }   
    }
}