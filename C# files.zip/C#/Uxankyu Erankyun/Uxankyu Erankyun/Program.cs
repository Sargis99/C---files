﻿using System;

namespace Uxankyu_Erankyun
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            int height = Convert.ToInt32(Console.ReadLine());
            String a = "*";
            for (int i = 0; i < height; i++)
            {
                Console.WriteLine(a);
                 
                a += " *";
            }
        }
    }
}