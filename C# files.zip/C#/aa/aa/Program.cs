﻿using System;

namespace aa
{
    class Program
    {
        public static  String  Symbol(int n,String b){
            String a = " ";
            for (int i = 0; i < n; i++)
                a =a+b;
            return a;
        }

        public static void Main(string[] args)
        {
            while (true)
            {
                int erk = int.Parse(Console.ReadLine());
                int space = erk;
                int qanak = 1;
                for (int i = 0; i < erk; i++)
                {
                    Console.WriteLine(Symbol(space, " ") + Symbol(qanak, "*"));
                    qanak += 2;
                    space -= 1;
                }
            }
        }
    }
    
}


