﻿using System;
using System.IO;
using Microsoft.Win32;

namespace ConsoleApplication4
{
    static public class Matem
    {
        public static int Pow (int a, int b)
        {
            if (a <= 0)
            {
                Console.WriteLine("Your number should be greater then 0");
                return 0;
            }

            else if (b == 0)
                return 1;
            else
            { 
                if (b <= 0)
                {
                    return a;
                }

                return a * Pow(a, b - 2);
            }
        }
        public static int sqrt(int num) {  
            if (0 == num) { return 0; }  
            int n = (num / 2) + 1;        
            int n1 = (n + (num / n)) / 2;  
            while (n1 < n) {  
                n = n1;  
                n1 = (n + (num / n)) / 2;  
            }  
            return n;  
        } 
        public static int abs(int a)
        {
            if (a >= 0)
                return a;
            else
                return (-1) * a;
        }

        public static int MaxTwoNum(int a, int b)
        {
            if (a > b)
                return a;
            else
                return b;
        }

        public static int MaxArray(int[] arr)
        {
            int k = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] > k)
                    k = arr[i];
            }

            return k;
        }

        public static int MinTwoNum(int a, int b)
        {
            if (a < b)
                return a;
            else
                return b;
        }

        public static int MinArray(int[] arr)
        {
            int k = arr[0];
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] < k)
                    k = arr[i];
            }

            return k;
        }

        public static int[] SortAscending(int[] arr)
        {
            int temp;
            for (int i = 0; i < arr.Length; i++)
            {
                for (int j = i+1; j < arr.Length; j++)
                {
                    if (arr[i] > arr[j])
                    {
                        temp = arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
                }
            }

            return arr;
        }

        public static int[] SortDescending(int[] arr)
        {
            int temp;
            for (int i = 0; i < arr.Length; i++)
            {
                for (int j = i+1; j < arr.Length; j++)
                {
                    if (arr[i] < arr[j])
                    {
                        temp = arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
                }
            }

            return arr;
        }

    }
}