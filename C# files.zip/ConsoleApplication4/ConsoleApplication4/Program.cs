﻿using System;

namespace ConsoleApplication4
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            int a = Matem.sqrt(10);
            Console.WriteLine(a);
        }
    }
}