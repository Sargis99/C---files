﻿using System;
using System.Data;
using System.Runtime.Remoting.Messaging;
using System.Security.Cryptography.X509Certificates;

namespace ConsoleApplication3
{
    public class Calculator
    {
        public Random rand;
        public Calculator()
        {
            rand = new Random();
        }

        public int[] Gen(int i)
        {
            int[] arr= new int[0];
            if (i == 1)
            {
                 arr = new int[1];
                arr[0] = rand.Next(1, 6);
            }
            else if (i == 2)
            {
                 arr = new int[2];
                for (int j = 0; j < 2; j++)
                {
                    arr[j] = rand.Next(1, 6);
                }

            }
            else if (i == 3)
            {
                 arr = new int[3];
                for (int j = 0; j < 3; j++)
                {
                    arr[j] = rand.Next(1, 6);
                }
            }
            
            return arr;
        }

      
    }
}