﻿using System;
using System.Security.Cryptography.X509Certificates;

namespace ConsoleApplication3
{
    public class Player
    {
        public string name;
        public int score;

        public Player(string name, int score)
        {
            this.score = score;
            this.name = name;
        }

        public int bet()
        {
            
            int a = Int32.Parse(Console.ReadLine());         
            return a;
        }

        public int[] Gues(int i)
        {
            int[] arr = new int[0];
            if (i == 1)
            {
                arr = new int[1];
                arr[0] = Int32.Parse(Console.ReadLine());
            }
            else if (i == 2)
            {
                arr = new int[2];
                for (int j = 0; j < 2; j++)
                {
                    arr[j]= Int32.Parse(Console.ReadLine());
                }
            }
            else if (i == 3)
            {
                arr = new int[3];
                for (int j = 0; j < 3; j++)
                {
                    arr[j]=Int32.Parse(Console.ReadLine());
                }
            }

            return arr;
        }

    }
}