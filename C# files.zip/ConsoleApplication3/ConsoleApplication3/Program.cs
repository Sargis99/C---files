﻿namespace ConsoleApplication3
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Game a = new Game();
            a.start();
        }
    }
}