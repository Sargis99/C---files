﻿using System;
using System.ComponentModel.Design;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    public class Game
    {
        Player a = new Player("Sarg",20);
        Calculator b = new Calculator();

        public void start()
        {
            int i = 0, j = 0,q=0;
            Console.WriteLine("Please choose option easy-1, medium-2, hard-3");
            int y = Int32.Parse(Console.ReadLine());
            int[] arr1 = new int[0];
            int[] arr2 = new int[0];
            while (a.score > 0)
            {
                Array.Clear(arr1, 0, arr1.Length);
                Array.Clear(arr2, 0, arr2.Length);
                i = 0;
                j = 0;
                Console.WriteLine("PLease enter the amount of your bet");
                int k = a.bet();
                if (k <= a.score)
                {
                    Console.WriteLine("Please enter the number");
                    
                         arr1 = a.Gues(y);
                         arr2 = b.Gen(y);
                    for ( i = 0; i < arr1.Length; i++)
                    {
                        q = 0;
                        if (arr1[i] > 0 && arr1[i] <= 6)
                        {
                            for (j = 0; j < arr2.Length; j++)
                            {
                                if (arr1[i] == arr2[j])
                                {
                                    q++;
                                }
                            }

                            if (q != 0)
                            {
                                if (q == 1)
                                {
                                    a.score += 2 * k;
                                    Console.WriteLine("Your guess is right" + " and your score is " + a.score);
                                }

                                if (q == 2)
                                {
                                    a.score += 2 * k;
                                    Console.WriteLine("Your guess is right" + " and your score is " + a.score);
                                    break;
                                }

                               
                            }
                            else
                            {
                                a.score -= k;
                                Console.WriteLine("Your guess is wrong your score is " + a.score);
                                if (a.score <= 0)
                                {
                                    Console.WriteLine("The end");
                                    break;
                                }

                            }
                        }
                        else
                            Console.WriteLine("Your number is out of range");
                    }

                }
                else
                {
                    Console.WriteLine("You do not have enough money");
                }

            }
        }

    }
}