﻿using System;
using System.Data.SqlClient;

namespace ConsoleApplication1
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            int n;
            n = Console.Read();
            int[,] a = new int[n, n];
            int m, y, x = 0, k = 0,q=1,p;
            m = n;
            y = n;
            if(n%2==0)
            	p=n/2;
            else
            	p=n/2+1;
            while (k<p)
            {
                for (int i = k; i < m; i++)
                {
                    a[x, i] = q;
                    q++;
                }
                x++;
                for (int i = x; i < y; i++)
                {
                    a[i, m - 1] = q;
                    q++;
                }

                m--;
                for (int i = m-1; i >=k; i--)
                {
                    a[y - 1, i] = q;
                    q++;
                }

                y--;
                for (int i = y-1; i >=x; i--)
                {
                    a[i, k] = q;
                    q++;
                }
                k++;
            }

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write(a[i,j]);
                }
                Console.WriteLine();
            }
        }
    }
}