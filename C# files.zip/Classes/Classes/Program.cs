﻿using System;

namespace Classes
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            int[] array = { 4,5,6,7,8,9,1,2};
            Dog n = new Dog(array,false);
            int[] k = n.BubleSortArray();
            for (int i = 0; i < k.Length; i++)
            {
                Console.WriteLine(k[i]);
            }
        }
        
    }
}