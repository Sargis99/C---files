﻿namespace Classes
{
    public class Dog
    {
        private int[] array;
        private bool b;

        public Dog(int[] array,bool b)
        {
            this.array = array;
            this.b = b;
        }

        public int[] BubleSortArray()
        {
            int length = array.Length;

            int temp ;
            if (b)
            {

                for (int i = 0; i < length; i++)
                {
                    for (int j = i + 1; j < length; j++)
                    {
                        if (array[i] > array[j])
                        {
                            temp = array[i];

                            array[i] = array[j];

                            array[j] = temp;
                        }
                    }
                }

                return array;
            }
            else
            {
                for (int i = 0; i < length; i++)
                {
                    for (int j = i + 1; j < length; j++)
                    {
                        if (array[i] <array[j])
                        {
                            temp = array[i];

                            array[i] = array[j];

                            array[j] = temp;
                        }
                    }
                }

                return array;
            }
        }
    }
}